const images=[
'images/001.jpg','images/002.jpg','images/003.jpg','images/004.jpg',
'images/005.jpg','images/006.jpg','images/007.jpg','images/008.jpg'
];
const mid=Math.ceil(images.length/2);
function fill(id,list){const g=document.getElementById(id);list.forEach((src,i)=>{const img=document.createElement('img');img.src=src;img.loading='lazy';img.style.maxWidth=(i%3==1?'65%':'100%');if(i%3==1)img.style.justifySelf='center';img.onclick=()=>{lb.style.display='flex';lbimg.src=src};g.appendChild(img);});}
fill('gallery1',images.slice(0,mid));fill('gallery2',images.slice(mid));
const lb=document.getElementById('lightbox'),lbimg=document.getElementById('lbimg');
document.getElementById('close').onclick=()=>lb.style.display='none';
lb.onclick=e=>{if(e.target===lb)lb.style.display='none';};
